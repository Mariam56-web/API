package com.example.final_ex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
